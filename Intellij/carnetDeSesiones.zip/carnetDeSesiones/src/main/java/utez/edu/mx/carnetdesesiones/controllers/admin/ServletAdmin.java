package utez.edu.mx.carnetdesesiones.controllers.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import utez.edu.mx.carnetdesesiones.models.Admin.Admin;
import utez.edu.mx.carnetdesesiones.models.Consultor.Consultor;
import utez.edu.mx.carnetdesesiones.models.Consultor.DaoConsultor;
import utez.edu.mx.carnetdesesiones.models.Group.DaoGroup;
import utez.edu.mx.carnetdesesiones.models.Group.Group;
import utez.edu.mx.carnetdesesiones.models.Student.DaoStudent;
import utez.edu.mx.carnetdesesiones.models.Student.Student;
import utez.edu.mx.carnetdesesiones.models.crud.Value;
import utez.edu.mx.carnetdesesiones.models.user.DaoUser;
import utez.edu.mx.carnetdesesiones.models.user.User;


import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "Admin",urlPatterns = {
        "/admin/panel",
        /*-----Student ----*/
        "/admin/student",
        "/admin/user-view-update",
        "/admin/user-view-one-update",
        "/admin/student/update",
        "/admin/student/delete",
        "/admin/student/save",
        "/admin/student/create"
        /*-----Student----*/
        /*-----Consultor----*/
        ,"/admin/consultor",
        "/admin/user-view-update-consultor",
        "/admin/user-view-one-update-consultor",
        "/admin/consultor/update",
        "/admin/consultor/create",
        "/admin/consultor/save",
        "/admin/consultor/delete"
        /*-----Consultor----*/
        /*-----Group----*/
        ,"/admin/Group",
        "/admin/user-view-update-Group",
        "/admin/user-view-one-update-Group",
        "/admin/Group/update",
        "/admin/Group/create",
        "/admin/Group/save",
        "/admin/Group/delete"
        /*-----Consultor----*/
})
public class ServletAdmin extends HttpServlet {
    private String action ;
    private String redirect = "/user/session" ;

    private String email,password ;
    private User user;

    private String id ;
    private String newid ;
    private Student student;
    private Consultor consultor;

    private List<Group> groups;
    private String Card;
    private String Camp;
    private String campv2;

    private String valor;

    private  Value context;

    protected void doGet(HttpServletRequest req , HttpServletResponse resp) throws ServletException , IOException
    {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action)
        {
            /*Vistasde lso usuarios */
            case  "/admin/panel":
                Admin admin = (Admin) user;
                req.setAttribute("user",admin);
                redirect = "/views/user/Admin/Inicio/panel.jsp";
                break;
            case  "/admin/student":
                List<Student> students = new DaoStudent().findAll();
                req.setAttribute("students" , students);
                redirect = "/views/user/Admin/users/student/ListEstudents.jsp";
                break;
            case  "/admin/consultor":
                List<Consultor> Consultors =  new DaoConsultor().findAll();
                req.setAttribute("Consultors" , Consultors);
                redirect = "/views/user/Admin/users/consultor/ListConsultors.jsp";
                break;
                /*-----------//Listas//------------*/

            /*---------Vista de datos de un usuario -------*/

            case "/admin/user-view-update":
                 newid = req.getParameter("id");
                if (newid != null ) id = req.getParameter("id");
                Student student = new Student();
                student = new DaoStudent().findOne(id != null  ? Long.parseLong(id) : 0 );
                if (student != null )
                {
                    req.setAttribute("student",student);
                    redirect = "/views/user/Admin/users/student/updateView.jsp";
                }
                else
                {
                    redirect = "/admin/student?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }
                break;
            case "/admin/user-view-update-consultor":
                 newid = req.getParameter("id");
                if (newid != null ) id = req.getParameter("id");
                consultor = new Consultor();
                consultor = new DaoConsultor().findOne(id != null  ? Long.parseLong(id) : 0 );
                if (consultor != null )
                {
                    req.setAttribute("consultor",consultor);
                    redirect = "/views/user/Admin/users/consultor/updateView.jsp";
                }
                else
                {
                    redirect = "/admin/consultor?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }
                break;

            /*---------//Vista de datos de un usuario// -------*/
            /*---------//Creacion de usuarios// -------*/
            case "/admin/student/create":

                groups = new DaoGroup().findAll();
                req.setAttribute("groups",groups);
                redirect = "/views/user/Admin/users/student/create.jsp";
                break;

                case "/admin/consultor/create":
                redirect = "/views/user/Admin/users/consultor/create.jsp";
                break;

            /*---------//Creacion de usuarios// -------*/



                /*---------Actualizar por uno ---------*/

            case "/admin/user-view-one-update":

                id = req.getParameter("id_student");
                Card = req.getParameter("Card");
                Camp = req.getParameter("Camp");

                Student sstudent = new Student();
                sstudent = new DaoStudent().findOne(id != null  ? Long.parseLong(id) : 0 );
                Value op = new Value(Card,Camp,sstudent);
                if (sstudent != null )
                {
                    groups = new DaoGroup().findAll();
                    req.setAttribute("groups",groups);
                    req.setAttribute("student",sstudent);
                    req.setAttribute("op",op);


                    redirect = "/views/user/Admin/users/student/updateOne.jsp";
                }
                else
                {
                    redirect = "../index.jsp?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }
                break;
            case "/admin/user-view-one-update-consultor":

                Card = req.getParameter("Card");
                Camp = req.getParameter("Camp");
                 consultor = new Consultor();
                consultor = new DaoConsultor().findOne(id != null  ? Long.parseLong(id) : 0 );
                 op = new Value(Card,Camp,consultor);
                if (consultor != null )
                {
                    req.setAttribute("consultor",consultor);
                    req.setAttribute("op",op);


                    redirect = "/views/user/Admin/users/consultor/updateOne.jsp";
                }
                else
                {
                    redirect = "/admin/user-view-update-consultor?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }



                break;
                /*//-------Actualizar por uno ------//*/

        }

        req.getRequestDispatcher(redirect).forward(req,resp);
    }
    @Override
    protected void doPost(HttpServletRequest req , HttpServletResponse resp ) throws  ServletException  , IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");



        action = req.getServletPath();
        switch (action)
        {
            /*----------//Delate de los usuarios//---------*/
            case "/admin/student/delete":
                 newid = req.getParameter("id_student_delate");
                if (newid != null ) id = req.getParameter("id_student_delate");

                if (new DaoStudent().delate(Long.parseLong(id)))
                {

                    redirect = "/admin/student";
                }
                else
                {
                    redirect = "/admin/user-view-update?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }



                break;
            case "/admin/consultor/delete":
                 newid = req.getParameter("id");
                if (newid != null ) id = req.getParameter("id_delate");

                if (new DaoConsultor().delate(Long.parseLong(id)))
                {

                    redirect = "/admin/consultor";
                }
                else
                {
                    redirect = "/admin/user-view-update-consultor?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }



                break;
            /*----------//Delate de los usuarios//---------*/

                /*-----------------------*/
            case "/admin/student/update":
                 campv2 = req.getParameter("object");
                 valor = req.getParameter("valor");
                 context = new Value(id,campv2,valor);
                if (   new DaoStudent().updateOne(context) )

                    redirect = "/admin/user-view-update";

                else
                    redirect = redirect = "/admin/user-view-one-update?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Tu usuario No se puedo Actualizar ", StandardCharsets.UTF_8);
                break;
            case "/admin/consultor/update":

                 campv2 = req.getParameter("object");
                 valor = req.getParameter("valor");
                System.out.println(campv2 + " " + valor);
                 context = new Value(id,campv2,valor);
                if (   new DaoConsultor().updateOne(context) )

                    redirect = "/admin/user-view-update-consultor";

                else
                    redirect = redirect = "/admin/user-view-update-consultor?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Tu usuario No se puedo Actualizar ", StandardCharsets.UTF_8);
                break;

                /*----------//Update de los usuarios//---------*/
            /*----------//Save de los usuarios//---------*/
            case "/admin/student/save":

                Group group = new Group();
                Student student = new Student();
                student.setName(req.getParameter("name"));
                student.setEmail( req.getParameter("email"));
                student.setPassword(req.getParameter("password"));
                student.setFirst_last_name(req.getParameter("first_last_name"));
                student.setSecond_last_name(req.getParameter("second_last_name"));
                student.setEnrollment(req.getParameter("enrollment"));
                student.setPhone(req.getParameter("phone"));
                group.setId_group(Long.parseLong(req.getParameter("answerInput-hidden")));

                student.setGroup(group);

                if (   new DaoStudent().save(student) )

                    redirect = "/admin/student";
                else
                    redirect = redirect = "/admin/student/create?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Tu usuario No se puedo Regsitar", StandardCharsets.UTF_8);


                break;
            case "/admin/consultor/save":


                 consultor = new Consultor();
                consultor.setName(req.getParameter("name"));
                consultor.setEmail( req.getParameter("email"));
                consultor.setPassword(req.getParameter("password"));
                consultor.setFirst_last_name(req.getParameter("first_last_name"));
                consultor.setSecond_last_name(req.getParameter("second_last_name"));


                if (   new DaoConsultor().save(consultor) )

                    redirect = "/admin/consultor";
                else
                    redirect = redirect = "/admin/consultor/create?result= " + false + "&message" +
                            "=" + URLEncoder.encode("¡Error! Tu usuario No se puedo Regsitar", StandardCharsets.UTF_8);


                break;

            /*----------//Save de los usuarios//---------*/



        }
        resp.sendRedirect(req.getContextPath()+redirect);

        }
}
