package utez.edu.mx.carnetdesesiones.controllers.consultor;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import utez.edu.mx.carnetdesesiones.models.Consultor.Consultor;
import utez.edu.mx.carnetdesesiones.models.Group.Group;
import utez.edu.mx.carnetdesesiones.models.Student.Student;
import utez.edu.mx.carnetdesesiones.models.crud.Value;
import utez.edu.mx.carnetdesesiones.models.user.User;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "Consultor",urlPatterns = {
        "/consultor/panel",





})
public class ServletConsultor extends HttpServlet {
    private String action ;
    private String redirect = "/user/session" ;

    private String email,password ;
    private User user;

    private String id ;
    private String newid ;
    private Student student;
    private Consultor consultor;

    private List<Group> groups;
    private String Card;
    private String Camp;
    private String campv2;

    private String valor;

    private  Value context;

    protected void doGet(HttpServletRequest req , HttpServletResponse resp) throws ServletException , IOException
    {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action)
        {
            /*Vistasde lso usuarios */
            case  "/consultor/panel":
                Consultor consultor = (Consultor) user;
                req.setAttribute("user",consultor);
                redirect = "/views/user/Consultor/panel.jsp";
                break;


        }


        req.getRequestDispatcher(redirect).forward(req,resp);
    }
    @Override
    protected void doPost(HttpServletRequest req , HttpServletResponse resp ) throws  ServletException  , IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");

        action = req.getServletPath();
        switch (action)
        {
            /*----------//Delate de los usuarios//---------*/

        }
        resp.sendRedirect(req.getContextPath()+redirect);

        }
}
