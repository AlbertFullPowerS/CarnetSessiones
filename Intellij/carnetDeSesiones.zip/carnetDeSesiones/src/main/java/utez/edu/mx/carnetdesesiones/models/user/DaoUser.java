package utez.edu.mx.carnetdesesiones.models.user;

import utez.edu.mx.carnetdesesiones.models.Admin.*;
import utez.edu.mx.carnetdesesiones.models.Consultor.*;
import utez.edu.mx.carnetdesesiones.models.Student.*;
import utez.edu.mx.carnetdesesiones.models.Tutor.*;
import utez.edu.mx.carnetdesesiones.models.crud.*;
import utez.edu.mx.carnetdesesiones.models.crud.*;
import utez.edu.mx.carnetdesesiones.utils.MySQL.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoUser implements DaoRepository<User> {

    private Connection conn;//Coneccion

    private PreparedStatement pstm; //Es domnde nosotros preparamos la sentencia sql y se pueda leer del lado del sql

    private ResultSet rs ;

    public  User  login(String email , String password) {
        User user = new User();


        try {

            conn = new MySQLConnection().getConnection(); // Coneccion a la base de datos
            String query = "CALL login(?,?);";//Cosulta que se manda a la base de datos

            pstm = conn.prepareStatement(query);
            pstm.setString(1, email);
            pstm.setString(2, password);//Prepara la consulta para mandar el query
            rs = pstm.executeQuery();//Trae la consulta y ejecuta el query

            if (rs.next()) {

                switch (rs.getString("Us")) {
                    case "Admin":
                       Admin admin = new Admin(rs.getLong("fk_user"), rs.getString("email"),
                                rs.getString("password"), rs.getString("name"),
                                rs.getString("first_last_name"), rs.getString("second_last_name"),rs.getLong("id_admin"));
                        return admin;
                    case "Consultants":
                        Consultor consultor = new Consultor(rs.getLong("fk_user"), rs.getString("email"),
                                rs.getString("password"), rs.getString("name"),
                                rs.getString("first_last_name"), rs.getString("second_last_name"),rs.getLong("id_consultant"));
                        return consultor;
                    case "Tutors":
                        tutor tutor = new tutor(rs.getLong("fk_user"), rs.getString("email"),
                                rs.getString("password"), rs.getString("name"),
                                rs.getString("first_last_name"), rs.getString("second_last_name"),rs.getLong("id_tutor"));
                        return tutor;

                    case "Student":
                        Student student = new Student();
                        return student;
                }
                System.out.println(rs.getString("Us"));

            }

            //


        } catch (SQLException e) {
            Logger.getLogger(DaoUser.class.getName())
                    .log(Level.SEVERE, "Error findAll" + e.getMessage());
        }
        return user;
    }

    @Override
    public List<utez.edu.mx.carnetdesesiones.models.user.User> findAll() {
        return null;
    }

    @Override
    public utez.edu.mx.carnetdesesiones.models.user.User findOne(long id) {
        return null;
    }

    @Override
    public boolean save(utez.edu.mx.carnetdesesiones.models.user.User object) {
        return false;
    }


    @Override
    public boolean update(User object) {
        return false;
    }

    @Override
    public boolean updateOne(Value object) {
        return false;
    }

    @Override
    public boolean delate(long id) {
        return false;
    }
}
