package utez.edu.mx.carnetdesesiones.models.Group;

import utez.edu.mx.carnetdesesiones.models.AcademicProgram.AcademicProgram;
import utez.edu.mx.carnetdesesiones.models.Periods.DaoPeriod;
import utez.edu.mx.carnetdesesiones.models.Periods.Periods;
import utez.edu.mx.carnetdesesiones.models.Student.DaoStudent;
import utez.edu.mx.carnetdesesiones.models.Student.Student;
import utez.edu.mx.carnetdesesiones.models.Tutor.Tutor;
import utez.edu.mx.carnetdesesiones.models.crud.DaoRepository;
import utez.edu.mx.carnetdesesiones.models.crud.Value;
import utez.edu.mx.carnetdesesiones.models.user.User;
import utez.edu.mx.carnetdesesiones.utils.MySQL.MySQLConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoGroup implements DaoRepository<Group> {
    private Connection conn;//Coneccion

    private CallableStatement call ;
    private PreparedStatement pstm; //Es domnde nosotros preparamos la sentencia sql y se pueda leer del lado del sql

    private ResultSet rs;
    @Override
    public List<Group> findAll() {
        List<Group> groups = null;
        try {
            groups = new ArrayList<>();
            conn = new MySQLConnection().getConnection(); // Coneccion a la base de datos
            String query = "select * from groups_list_min;";//Cosulta que se manda a la base de datos
            pstm = conn.prepareStatement(query);//Prepara la consulta para mandar el query
            rs = pstm.executeQuery();//Trae la consulta y ejecuta el query
            while (rs.next())//Verifica si hay datos
            {

                Group group = new  Group ();
                AcademicProgram academicProgram = new AcademicProgram();
                academicProgram.setProgramName(rs.getString("program_name"));
                group.setId_group(rs.getLong("id_group"));
                group.setGroup(rs.getString("group"));
                group.setGrade(rs.getString("grade"));
                group.setAcademic_program(academicProgram);

                groups.add(group);


            }

        } catch (SQLException e) {
            Logger.getLogger(DaoStudent.class.getName())
                    .log(Level.SEVERE, "Error findAll" + e.getMessage());
        }finally {
            close();
        }
        return groups;
    }

    public List<Group> findAllMax() {
        List<Group> groups = null;
        try {
            groups = new ArrayList<>();
            conn = new MySQLConnection().getConnection(); // Coneccion a la base de datos
            String query = "select * from groups_list;";//Cosulta que se manda a la base de datos
            pstm = conn.prepareStatement(query);//Prepara la consulta para mandar el query
            rs = pstm.executeQuery();//Trae la consulta y ejecuta el query
            while (rs.next())//Verifica si hay datos
            {

                Group group = new  Group ();
                Tutor tutor = new Tutor();
                Periods period = new Periods();
                AcademicProgram academicProgram = new AcademicProgram();
                academicProgram.setProgramName(rs.getString("program_name"));
                group.setId_group(rs.getLong("id_group"));
                group.setGroup(rs.getString("group"));
                group.setGrade(rs.getString("grade"));
                group.setAcademic_program(academicProgram);
                tutor.setName(rs.getString("name"));
                tutor.setFirst_last_name(rs.getString("first_last_name"));
                period.setName(rs.getString("period_name"));
                period.setDateBegin(rs.getString("date_begin"));

                group.setTutor(tutor);
                group.setPeriodo(period);

                groups.add(group);


            }

        } catch (SQLException e) {
            Logger.getLogger(DaoGroup.class.getName())
                    .log(Level.SEVERE, "Error findAll" + e.getMessage());
        }finally {
            close();
        }
        return groups;
    }
    @Override
    public Group findOne(long id) {

        try {
            conn = new MySQLConnection().getConnection();
            String query = "select *from periods where id_period = ?";
            pstm = conn.prepareStatement(query);
            pstm.setLong(1 , id);
            rs = pstm.executeQuery();

            Periods period= new Periods();
            if (rs.next())
            {
                period.setId_Periods(rs.getLong("id_period"));
                period.setName(rs.getString("name"));
                period.setDateBegin(rs.getString("date_begin"));
                period.setDateEnd(rs.getString("date_end"));

            }
            return period;
        }
        catch (SQLException e) {
            Logger.getLogger(DaoPeriod.class.getName())
                    .log(Level.SEVERE,"Error findOne" + e.getMessage());
        }finally {
            close();
        }

        return null;

    }

    @Override
    public boolean save(Group object) {
        return false;
    }

    @Override
    public boolean update(Group object) {
        return false;
    }

    @Override
    public boolean updateOne(Value object) {
        return false;
    }

    @Override
    public boolean delate(long id) {
        return false;
    }
    public void close(){
        try{
            if(conn != null ) conn.close();
            if(pstm != null ) conn.close();
            if(rs != null ) conn.close();


        }catch(SQLException e)
        {
            Logger.getLogger(DaoStudent.class.getName())
                    .log(Level.SEVERE,"Error findAll" + e.getMessage());
        }
    }
}
