package utez.edu.mx.carnetdesesiones.controllers.user;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import utez.edu.mx.carnetdesesiones.models.Admin.Admin;
import utez.edu.mx.carnetdesesiones.models.Consultor.Consultor;
import utez.edu.mx.carnetdesesiones.models.Tutor.tutor;
import utez.edu.mx.carnetdesesiones.models.Student.Student;
import utez.edu.mx.carnetdesesiones.models.user.DaoUser;
import utez.edu.mx.carnetdesesiones.models.user.User;


import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "users",urlPatterns = {
        "/user/login"
})
public class ServletUser extends HttpServlet {
    private String action ;
    private String redirect = "/user/session" ;

    private String email,password ;
    private User user;

    protected void doPost(jakarta.servlet.http.HttpServletRequest req, jakarta.servlet.http.HttpServletResponse resp) throws jakarta.servlet.ServletException, java.io.IOException
    {
        req.setCharacterEncoding("UTF-8");
        action = req.getServletPath();
        switch (action)
        {
            case  "/user/login":
                email = req.getParameter("email");
                password = req.getParameter("password");

                User user = new DaoUser().login(email, password);

                switch (user.getClass().getSimpleName())
                {
                    case "Admin":
                        Admin admin = (Admin) user;
                        req.setAttribute("user",admin);
                        redirect = "/views/user/Admin/Inicio/panel.jsp";
                        break;
                    case "Consultor":
                        Consultor consultor = (Consultor) user;
                        req.setAttribute("user",consultor);
                        redirect = "/views/user/Consultor/panel.jsp";
                        break;
                    case "Student":
                        Student student = (Student) user;
                        req.setAttribute("user",student);
                        redirect = "/views/user/Student/panel.jsp";
                        break;
                    case "tutor":
                        tutor tutor = (tutor) user;
                        req.setAttribute("user",tutor);
                        redirect = "/views/user/Tutor/panel.jsp";
                        break;
                    default:
                        redirect = "../index.jsp?result= " + false + "&message" +
                                "=" + URLEncoder.encode("¡Error! Accion no relizada", StandardCharsets.UTF_8);
                }




                break;
        }
        req.getRequestDispatcher(redirect).forward(req,resp);
    }

}
