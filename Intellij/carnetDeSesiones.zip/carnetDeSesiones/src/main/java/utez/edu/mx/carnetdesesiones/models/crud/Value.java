package utez.edu.mx.carnetdesesiones.models.crud;

import utez.edu.mx.carnetdesesiones.models.Student.Student;
import utez.edu.mx.carnetdesesiones.models.user.User;

public class Value {
    private String Card;
    private String Camp;

    private String valueView;
    private String Campv2;


    private String idU;
    private String attr;
    private String data;

    public Value(String idU, String attr, String data) {
        this.idU = idU;
        this.attr = attr;
        this.data = data;
    }

    public String getIdU() {
        return idU;
    }

    public void setIdU(String idU) {
        this.idU = idU;
    }

    public String getAttr() {
        return attr;
    }

    public void setAttr(String attr) {
        this.attr = attr;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getValueView() {
        return valueView;
    }

    public void setValueView(String valueView) {
        this.valueView = valueView;
    }

    public String getCampv2() {
        return Campv2;
    }

    public void setCampv2(String campv2) {
        Campv2 = campv2;
    }
    public Value (String Card, String Camp, User user) {
        this.Card = Card;
        this.Camp = Camp;
        switch (Camp){
            case "Nombre":
                this.Campv2="name";
                this.valueView = user.getName();
                break;
            case "Telefono":
                this.Campv2="phone_number";
                this.valueView = user.getName();
                break;
            case "Apellido Paterno":
                this.Campv2="first_last_name";
                this.valueView = user.getFirst_last_name();
                break;
            case "Apellido Materno":
                this.Campv2="second_last_name";
                this.valueView = user.getSecond_last_name();
                break;
            case "Email":
                this.Campv2="email";
                this.valueView = user.getEmail();
                break;
            case "Contrasela":
                this.Campv2="password";

                break;
            case "Grupo":
                this.Campv2="fk_group";
                break;
            case "Estado":
                this.Campv2="status";
                Student student = (Student) user;
                this.valueView = student.getStatus();
                break;
            case "Matricula":
                this.Campv2="enrollment";
                Student studen = (Student) user;
                this.valueView = studen.getEnrollment();
                break;
        }

    }
    public Value(){

    }


    public String getCard() {
        return Card;
    }

    public void setCard(String Card) {
        this.Card = Card;
    }

    public String getCamp() {
        return Camp;
    }

    public void setCamp(String Camp) {
        this.Camp = Camp;
    }
}
